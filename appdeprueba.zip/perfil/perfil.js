// Variables

const profilePicture = document.getElementById('profile-picture');

const pictureUpload = document.getElementById('picture-upload');
const profileName = document.getElementById('profile-name');
const profileDOB = document.getElementById('profile-dob');
const followButton = document.getElementById('follow-button');
const followerCount = document.getElementById('follower-count').querySelector('span');
const editName = document.getElementById('edit-name');
const editDOB = document.getElementById('edit-dob');
const saveButton = document.getElementById('save-button');

// Event Listeners
pictureUpload.addEventListener('change', updateProfilePicture);
followButton.addEventListener('click', toggleFollow);
saveButton.addEventListener('click', saveChanges);

// Functions
function updateProfilePicture(event) {
  const file = event.target.files[0];
  const reader = new FileReader();

  reader.onload = function(e) {
    profilePicture.src = e.target.result;
  };

  reader.readAsDataURL(file);
}

function toggleFollow() {
  if (followButton.innerText === 'Seguir') {
    followButton.innerText = 'Dejar de seguir';
    followerCount.innerText = parseInt(followerCount.innerText) + 1;
  } else {
    followButton.innerText = 'Seguir';
    followerCount.innerText = parseInt(followerCount.innerText) - 1;
  }
}

function saveChanges() {
  const newName = editName.value.trim();
  const newDOB = editDOB.value;

  if (newName !== '') {
    profileName.innerText = newName;
  }

  if (newDOB !== '') {
    profileDOB.innerText = newDOB;
  }

  editName.value = '';
  editDOB.value = '';

}
