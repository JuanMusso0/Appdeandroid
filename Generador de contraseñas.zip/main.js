document.getElementById('menu-btn').addEventListener('click', function() {
    var menu = document.getElementById('menu');
    menu.classList.toggle('show-menu');
});
// Agregar un manejador de eventos a los enlaces del menú principal
document.querySelectorAll('#menu ul li a').forEach(function(link) {
    link.addEventListener('click', function(event) {
        // Evitar que se active la función openTab() al hacer clic en los enlaces del menú
        event.stopPropagation();
    });
});

//funcion de las pestañas de abjo//
function openTab(tabName) {
  // Redireccionar a la página correspondiente al hacer clic en el icono
  switch(tabName) {
    case 'tab1':
      window.location.href = '#'; // Cambiar "pagina1.html" por la URL de tu primera página HTML
      break;
    case 'tab2':
      window.location.href = 'pagina2.html'; // Cambiar "pagina2.html" por la URL de tu segunda página HTML
      break;
    case 'tab3':
      window.location.href = 'pagina3.html'; // Cambiar "pagina3.html" por la URL de tu tercera página HTML
      break;
    default:
      break;
  }
}
